#include<iostream>
using namespace std;

class Node{
    public:
    int data;
    Node* next;
    
    // constructor
    Node(int data){
        this -> data = data;
        this -> next = NULL;
    }
    
};

void InsertAtHead(Node* &head , int d)
{
    // always create a new node whenever you are given a data
    Node* temp = new Node(d);
    temp-> next = head;
    head = temp;
    
}

void insertAtTail(Node* &tail, int d)
{
    Node* temp = new Node(d);
    tail->next = temp;
    tail = tail->next;
}

// generic code
void insertAtPosition(Node* &head, Node* &tail, int position, int d)
{
    // insert at start (updation at head)
    if(position==1)
    {
        InsertAtHead(head,d);
        return;
    }
    
    // insert at end (updation at tail)
    // if(len == position)
    // {
    //     insertAtTail(tail,d);
    // } // but hme length pta nhi h toh hm isko use nhi kr skte
    
    Node* temp = head;
    int cnt=1;
    
    while(cnt<position-1)
    {
        temp=temp->next;
        cnt++;
    }
    // to handle last node case
    if(temp->next==NULL)
    {
        insertAtTail(tail,d);
        return;
    }
    
    
    Node* nodetoinsert = new Node(d);
    nodetoinsert->next = temp->next;
    temp->next = nodetoinsert;
    
}

void print(Node* &head)
{
    Node* temp = head;
    while(temp!=NULL)
    {
        cout<<temp->data<<endl;
        temp=temp->next;
    }
    cout << endl;
}

int main(){
    Node* node1 = new Node(10);
    // head pointed to Node1
    
    Node* head = node1;
    // print(head);
    // InsertAtHead(head,20);
    // InsertAtHead(head, 15);
    // print(head);
    
    
    Node* tail = node1;
    insertAtTail(tail,20);
    print(head);
    insertAtTail(tail, 30);
    insertAtTail(tail,40);
    print(head);
    
    insertAtPosition(head,tail, 3, 567);
    insertAtPosition(head, tail, 5, 786);
    print(head);
    // to verify that head and tail are at correct position
    cout<<head->data<<endl;
    cout<<tail->data<<endl;
}